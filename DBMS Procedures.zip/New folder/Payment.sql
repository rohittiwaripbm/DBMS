-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE AddPayment
	-- Add the parameters for the stored procedure here
	@CustomerId as int,
	@MonthId as int,
	@Year as int,
	@IsPaid as bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	--INSERT INTO Rohit_ExpansesDetails SELECT @Complainid,E.EXPANSETYPE, C.COST  
	--FROM
	--@COST AS C, @EXPENSETYPE AS E 
	--WHERE 
	--C.ID = E.ID
	INSERT INTO Payment SELECT @CustomerId, C.PackageId, @MonthId,@Year, @IsPaid
	FROM Customer AS C WHERE C.Id = @CustomerId

END
GO
