-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE RaiseComplain
	-- Add the parameters for the stored procedure here
	@CustomerId as int,
	@Complain as nvarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	Declare @ComplainTable as Table(complains nvarchar(100))
	 insert into @ComplainTable(complains) SELECT value  FROM STRING_SPLIT(@Complain, ',');

	SET NOCOUNT ON;
	
    -- Insert statements for procedure here

	--INSERT INTO Rohit_ExpansesDetails SELECT @Complainid,E.EXPANSETYPE, C.COST  
	--FROM
	--@COST AS C, @EXPENSETYPE AS E 
	--WHERE 
	--C.ID = E.ID

	INSERT INTO COMPLAIN(CustomerId, Description, RaisedDate) 
	SELECT @CustomerId, C.complains, GETDATE() FROM @ComplainTable AS C
END
GO
