EXEC XMLFormatResolveComplain 3,'<CableOperator><ResolveComplain ID = "1" cost = "200"/>
			<ResolveComplain  ID = "2" cost = "300"/>
			</CableOperator>'

select * from ExpensesDetails